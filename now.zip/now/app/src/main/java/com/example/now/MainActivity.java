package com.example.now;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText etUserName, etPassword, etAddress, etAge, etDOB;
    private Spinner spinnerState;
    private TextView tvResult;
    private String selectedGender = "Male";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_main);

        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        etAddress = findViewById(R.id.etAddress);
        etAge = findViewById(R.id.etAge);
        etDOB = findViewById(R.id.etDOB);
        RadioGroup rgGender = findViewById(R.id.rgGender);
        spinnerState = findViewById(R.id.spinnerState);
        Button btnSubmit = findViewById(R.id.btnSubmit);
        tvResult = findViewById(R.id.tvResult);

        // Gender selection
        rgGender.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbMale) {
                selectedGender = "Male";
            } else if (checkedId == R.id.rbFemale) {
                selectedGender = "Female";
            }
        });

        // Date Picker for DOB
        etDOB.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) ->
                            etDOB.setText(selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear),
                    year, month, day);
            datePickerDialog.show();
        });

        // Spinner setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.states_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerState.setAdapter(adapter);

        // Submit button click listener
        btnSubmit.setOnClickListener(v -> {
            String userName = etUserName.getText().toString();
            String password = etPassword.getText().toString();
            String address = etAddress.getText().toString();
            String age = etAge.getText().toString();
            String dob = etDOB.getText().toString();
            String state = spinnerState.getSelectedItem().toString();

            String result = "User Name: " + userName + "\n" +
                    "Password: " + password + "\n" +
                    "Address: " + address + "\n" +
                    "Gender: " + selectedGender + "\n" +
                    "Age: " + age + "\n" +
                    "Date of Birth: " + dob + "\n" +
                    "State: " + state;
            tvResult.setText(result);
        });
    }
}
